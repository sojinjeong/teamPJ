package school.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import school.dto.SDto;

public class StudentsDao {
	
		//필드
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn;
		
		//생성자에서 db 접속
		public StudentsDao(Connection conn) {
			this.conn = conn;
		}

		//회원가입
		public int insertDB(SDto dto) {
			int num = 0;
			String sql = "insert into student "
					+ " (id, name, stNum, pass, add1, add2, phoneNum, birth, email) "
					+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, dto.getId());
				pstmt.setString(2, dto.getUsername());
				pstmt.setInt(3, dto.getStNum());
				pstmt.setString(4, dto.getUserpass());
				pstmt.setString(5, dto.getAddr1());
				pstmt.setString(6, dto.getAddr2());
				pstmt.setString(7, dto.getUsertel());
				pstmt.setInt(8, dto.getBirth());
				pstmt.setString(9, dto.getUseremail());
				System.out.println(pstmt);
				num = pstmt.executeUpdate();
				
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				  try {
						if(pstmt != null) pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return num;
		}
		
		//회원중복 검증
		public boolean findUser(String column, String uname) {
			boolean res = true;
			String sql = "select * from student where "+ column + "= ?";
			try {
			   pstmt = conn.prepareStatement(sql);
			   pstmt.setString(1, uname);	;
			   rs = pstmt.executeQuery();
			   if(rs.next()) {
				   res = false;
			   }
			}catch(SQLException e) {
			      e.printStackTrace();
		    }finally {
			  try {
				if(pstmt != null) pstmt.close();
			  } catch (SQLException e) {
				  e.printStackTrace();
			  }
			}
			return res;
		}
		
}
