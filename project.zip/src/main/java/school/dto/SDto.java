package school.dto;

//학생 정보 DB
public class SDto {
	
	private int id;
	private String userpass;
	private String username;
	private String useremail;
	private String usertel;
	private String addr1;
	private String addr2;
	private String role;
	private int birth;
	private int stNum;
	private int lectureNum1;
	private int lectureNum2;
	private int lectureNum3;
	private int lectureNum4;
	
	public SDto() {}

	public SDto(int id, int stNum, String userpass, String username, String useremail, String usertel, String addr1,
			String addr2, String role, int birth) {
		super();
		this.id = id;
		this.stNum = stNum;
		this.userpass = userpass;
		this.username = username;
		this.useremail = useremail;
		this.usertel = usertel;
		this.addr1 = addr1;
		this.addr2 = addr2;
		this.role = role;
		this.birth = birth;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStNum() {
		return stNum;
	}

	public void setStNum(int stNum) {
		this.stNum = stNum;
	}

	public String getUserpass() {
		return userpass;
	}

	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsertel() {
		return usertel;
	}

	public void setUsertel(String usertel) {
		this.usertel = usertel;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public int getBirth() {
		return birth;
	}

	public void setBirth(int birth) {
		this.birth = birth;
	}	
	
	public int getLectureNum1() {
		return lectureNum1;
	}

	public void setLectureNum1(int lectureNum1) {
		this.lectureNum1 = lectureNum1;
	}	
	
	public int getLectureNum2() {
		return lectureNum2;
	}

	public void setLectureNum2(int lectureNum2) {
		this.lectureNum2 = lectureNum2;
	}

	public int getLectureNum3() {
		return lectureNum3;
	}

	public void setLectureNum3(int lectureNum3) {
		this.lectureNum3 = lectureNum3;
	}

	public int getLectureNum4() {
		return lectureNum4;
	}

	public void setLectureNum4(int lectureNum4) {
		this.lectureNum4 = lectureNum4;
	}

}
